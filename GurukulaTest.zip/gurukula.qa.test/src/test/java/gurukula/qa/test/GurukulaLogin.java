package gurukula.qa.test;

import java.io.File;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GurukulaLogin {
WebDriver driver;

@BeforeTest

public void launchBrowser() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHWETA\\chromedriver.exe");	
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

	
	@Test (priority = 1)
	
	public void LoginMethod() throws IOException {
		
	
		 driver.get("http://127.0.0.1:8080/#/");
		    driver.findElement(By.linkText("login")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Automatic Login'])[1]/following::button[1]")).click();
		    {
			    try {
			    	driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/div[1]"));
			        System.out.println("Element Present");
			    }
			    catch(NoSuchElementException e) {
			    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    	FileUtils.copyFile(screenshot, new File("D:\\screenshot1.jpeg"));	
			    }
				    }
		    driver.findElement(By.id("username")).click();
		    driver.findElement(By.id("username")).clear();
		    driver.findElement(By.id("username")).sendKeys("admin");
		    driver.findElement(By.id("password")).click();
		    driver.findElement(By.id("password")).clear();
		    driver.findElement(By.id("password")).sendKeys("admin");
		    driver.findElement(By.id("rememberMe")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Automatic Login'])[1]/following::button[1]")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Entities'])[1]/following::b[1]")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Entities'])[1]/following::span[2]")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::span[1]")).click();
		    {
			    try {
			    	driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[1]/div/div[1]/button/span[2]"));
			        System.out.println("Element Present");
			    }
			    catch(NoSuchElementException e) {
			    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    	FileUtils.copyFile(screenshot, new File("D:\\screenshot2.jpeg"));	
			    }
				    }
		    driver.findElement(By.linkText("Entities")).click();
		    driver.findElement(By.linkText("Staff")).click();
		    {
			    try {
			    	driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[1]/div/div[1]/button/span[2]"));
			        System.out.println("Element Present");
			    }
			    catch(NoSuchElementException e) {
			    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    	FileUtils.copyFile(screenshot, new File("D:\\screenshot3.jpeg"));	
			    }
				    }
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::span[5]")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::b[1]")).click();
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Sessions'])[1]/following::span[2]")).click();
		
	}
@Test (priority = 2)
	
	public void NewUserMethod() throws IOException {
		

		  driver.get("http://127.0.0.1:8080/#/");
		    driver.findElement(By.linkText("Register a new account")).click();
		    driver.findElement(By.name("login")).clear();
		    driver.findElement(By.name("login")).sendKeys("admin1");
		    driver.findElement(By.name("email")).click();
		    driver.findElement(By.name("email")).clear();
		    driver.findElement(By.name("email")).sendKeys("amitapte1985@gmail.com");
		    driver.findElement(By.name("password")).click();
		    driver.findElement(By.name("password")).clear();
		    driver.findElement(By.name("password")).sendKeys("Admin@123");
		    driver.findElement(By.name("confirmPassword")).click();
		    driver.findElement(By.name("confirmPassword")).clear();
		    driver.findElement(By.name("confirmPassword")).sendKeys("Admin@123");
		    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='New password confirmation'])[1]/following::button[1]")).click();
		    try {
			    	driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::span[5]"));
			        System.out.println("Element Present");
			    }
			    catch(NoSuchElementException e) {
			    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			    	FileUtils.copyFile(screenshot, new File("D:\\screenshot4.jpeg"));
		    }
		    
		    
}

@Test (priority = 3)

public void testGurukulaBranches() {
	driver.get("http://127.0.0.1:8080/#/");
    driver.findElement(By.linkText("login")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("admin");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("admin");
    driver.findElement(By.id("rememberMe")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Automatic Login'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::span[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Entities'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Branches'])[2]/following::button[1]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).sendKeys("Gurukula English");
    driver.findElement(By.name("code")).click();
    driver.findElement(By.name("code")).sendKeys("523");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Branches'])[2]/following::span[2]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("Gurukula Hindi");
    driver.findElement(By.name("code")).click();
    driver.findElement(By.name("code")).clear();
    driver.findElement(By.name("code")).sendKeys("ABC");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Branches'])[2]/following::span[2]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("Gurukula English");
    driver.findElement(By.name("code")).click();
    driver.findElement(By.name("code")).clear();
    driver.findElement(By.name("code")).sendKeys("DEF");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Gurukula English'])[1]/following::span[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='View'])[2]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[3]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[2]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Entities'])[1]/following::b[1]")).click();
    driver.findElement(By.linkText("Branch")).click();
    driver.findElement(By.id("searchQuery")).click();
    driver.findElement(By.id("searchQuery")).clear();
    driver.findElement(By.id("searchQuery")).sendKeys("English");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Create a new Branch'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Gurukula English'])[1]/following::span[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Code'])[1]/following::span[2]")).click();
    
    try {
    	
    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(screenshot, new File("D:\\screenshot5.jpeg"));
    }
    catch(Exception e) {
    	System.out.println("Failure to take screenshot "+e);
    }
    finally
    {
    	driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::span[5]")).click();
    }
    
}
@Test (priority = 4)

public void testGurukulaStaff() {
	driver.get("http://127.0.0.1:8080/#/");
    driver.findElement(By.linkText("login")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("admin");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("admin");
    driver.findElement(By.id("rememberMe")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Automatic Login'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::span[1]")).click();
    driver.findElement(By.linkText("Staff")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Staffs'])[2]/following::span[2]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("Amit Apte");
    driver.findElement(By.name("related_branch")).click();
    new Select(driver.findElement(By.name("related_branch"))).selectByVisibleText("Gurukula English");
    driver.findElement(By.name("related_branch")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Staffs'])[2]/following::button[1]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("Shweta Apte");
    driver.findElement(By.name("related_branch")).click();
    new Select(driver.findElement(By.name("related_branch"))).selectByVisibleText("Gurukula Hindi");
    driver.findElement(By.name("related_branch")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Staffs'])[2]/following::span[2]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("Amol Apte");
    driver.findElement(By.name("related_branch")).click();
    new Select(driver.findElement(By.name("related_branch"))).selectByVisibleText("Gurukula English");
    driver.findElement(By.name("related_branch")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::button[1]")).click();
    driver.findElement(By.linkText("<<")).click();
    driver.findElement(By.linkText(">>")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='View'])[3]/following::span[1]")).click();
    driver.findElement(By.name("name")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("Ayush Apte");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Gurukula English'])[3]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Branch'])[2]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[3]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[2]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::b[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Sessions'])[1]/following::span[2]")).click();
    driver.findElement(By.linkText("Entities")).click();
    driver.findElement(By.linkText("Staff")).click();
    driver.findElement(By.id("searchQuery")).click();
    driver.findElement(By.id("searchQuery")).clear();
    driver.findElement(By.id("searchQuery")).sendKeys("Shweta");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Create a new Staff'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Shweta Apte'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Branch'])[2]/following::span[2]")).click();
    try {
    	
    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(screenshot, new File("D:\\screenshot6.jpeg"));
    }
    catch(Exception e) {
    	System.out.println("Failure to take screenshot "+e);
    }
    finally
    {
    	driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::span[5]")).click();
    }
    
}

@Test (priority = 5)

public void testGurukulaAccount() {
	driver.get("http://127.0.0.1:8080/#/");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::b[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::span[2]")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("admin");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("admin");
    driver.findElement(By.id("rememberMe")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Automatic Login'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Staff'])[1]/following::span[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::span[2]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Language'])[1]/following::button[1]")).click();
try {
    	
    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(screenshot, new File("D:\\screenshot7.jpeg"));
    }
    catch(Exception e) {
    	System.out.println("Failure to take screenshot "+e);
    }
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::b[1]")).click();
    driver.findElement(By.linkText("Password")).click();
try {
    	
    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(screenshot, new File("D:\\screenshot8.jpeg"));
    }
    catch(Exception e) {
    	System.out.println("Failure to take screenshot "+e);
    }
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::b[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Password'])[2]/following::span[2]")).click();
try {
    	
    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(screenshot, new File("D:\\screenshot9.jpeg"));
    }
    catch(Exception e) {
    	System.out.println("Failure to take screenshot "+e);
    }
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Account'])[1]/following::b[1]")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Sessions'])[2]/following::span[2]")).click();
	
    try {
    	
    	File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(screenshot, new File("D:\\screenshot10.jpeg"));
    }
    catch(Exception e) {
    	System.out.println("Failure to take screenshot "+e);
    }
    finally
    {
    	driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::span[5]")).click();
    }
    
}
@AfterTest

public void terminateBrowser() {
	  driver.close();
}
}
